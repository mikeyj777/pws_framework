class Exceptions:
  unspecified_error = "Unspecified Error"
  vessel_leak_state_model_failure = "Vessel State Calculation Failed"
  flash_calc_failed = "Flash Calc Failed"
  invalid_inputs = "Invalid Inputs Received in Model"
  discharge_calc_failure = "Vessel Leak Calculation Failed"
  dispersion_calc_failed = "Dispersion Calculation Failed"
